To use the app, it needs to be re-copied. (You can try to just double-click it to see if it works, but it most likely will not.)
There are several ways to do that. (Just double-clicking will not work because I am not an "Identified developer".)


Way #1:
  Right-click UNOPENABLE.app and click "Show Package Contents".
  Make a new folder.
  Copy "Contents" from the app into the new folder.
  Rename the new folder to something.app or whatever. I suggest MemorizationHelper.app.
  It will run now (hopefully)
	tell me if it doesn't

Way #2:
  Open Terminal.app (in /Applications/Utilities)
  Drag the "install" file (from the zip) and drop it onto the terminal window.
  A line of text should be entered.
  Click enter.
  A new application should be there. (It looks like it was only renamed).