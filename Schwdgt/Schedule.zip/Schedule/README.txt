To use the widget, the "Schedule.wdgt" file needs to get to your ~/Library/Widgets folder.
There are several ways to get it there. (Just double-clicking will not work because I am not an "Identfied developer".)


Way #1:
  Open a new Finder window and click in the menubar Go>Go to folder... and enter "~/Library/Widgets" without quotes and click Go. It may give you an error. Then you need to go to ~/Library and create a folder called "Widgets"
  Move Schedule.wdgt to this folder.
  Delete whatever is left over from the zip.
  Open dashboard, click the plus(+) in the lower left corner, and wait about 5 seconds for the widget to show up.


Way #2:
  Open Terminal.app (in /Applications/Utilities)
  Drag the "install" file (from the zip) and drop it onto the terminal window.
  A line of text should be entered.
  Click enter.
  Open dashboard, click the plus(+) in the lower left corner, and wait about 5 seconds for the widget to show up.
